/*
 *	$Header: D:/c_kram/nt_info/RCS/versinfo.h,v 1.2 1998/04/14 15:41:46 LUEVELSMEYER Exp $
 *
 *	checked in by $Author: LUEVELSMEYER $
 *	checked in at $Date: 1998/04/14 15:41:46 $
 *
 *	History:
 *	$Log: versinfo.h,v $
 *	Revision 1.2  1998/04/14 15:41:46  LUEVELSMEYER
 *	added comments
 *
 *	Revision 1.1  1997/06/05 11:23:42  LUEVELSMEYER
 *	Initial revision
 *
 *
 */


extern void print_version_info(char * progname);
    /* dumps version info, if it is in the file */

