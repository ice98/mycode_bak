contents of the archive
=======================

pe.txt          ASCII text describing PE file format

pe_map.c        C source of program that dumps PE files
versinfo.*      C source of helper-routine that dumps version resource
pe_map.exe      executable for NT on Intel platforms

hello.exe       file that's used as an example in 'pe.txt'

