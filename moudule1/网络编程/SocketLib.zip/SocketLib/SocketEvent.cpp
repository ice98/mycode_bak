//**********************************************************************
//
// Copyright (C) 2005-2007 Zhang bao yuan(bolidezhang@gmail.com).
// All rights reserved.
//
// This copy of Socketlib is licensed to you under the terms described 
// in the LICENSE.txt file included in this distribution.
//
//**********************************************************************

#include ".\socketevent.h"
namespace SL
{

CSocketEvent::CSocketEvent(void)
{
}

CSocketEvent::~CSocketEvent(void)
{
}

}