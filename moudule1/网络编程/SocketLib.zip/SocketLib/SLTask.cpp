#include ".\sltask.h"

//CSLTask::CSLTask(void)
//{
//}
//
//CSLTask::~CSLTask(void)
//{
//}
